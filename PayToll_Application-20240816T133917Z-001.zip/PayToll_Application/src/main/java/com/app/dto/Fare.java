package com.app.dto;

import lombok.Data;

@Data
public class Fare {
	
	private Long boothFareID;
	
	private String vehicleType;
	
	private double fare;

}
