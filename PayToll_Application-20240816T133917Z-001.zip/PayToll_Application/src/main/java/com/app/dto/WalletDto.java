package com.app.dto;

import lombok.Data;

@Data
public class WalletDto {
	
	private Long walletID;

	private double balanceAmount;
}
