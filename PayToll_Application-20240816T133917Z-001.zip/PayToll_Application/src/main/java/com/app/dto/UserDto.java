package com.app.dto;

import lombok.Data;

@Data
public class UserDto {

	private Long userID;
	
	private String userName;
	
	private String email;
	
	private String phoneNo;
	
}
