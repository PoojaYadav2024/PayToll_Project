package com.app.dto;

import lombok.Data;

@Data
public class TollBoothDto {

	private Long boothID;

	private String boothName;
}
