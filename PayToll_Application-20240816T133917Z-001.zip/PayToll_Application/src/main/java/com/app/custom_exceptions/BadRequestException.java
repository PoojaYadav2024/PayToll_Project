package com.app.custom_exceptions;

public class BadRequestException extends RuntimeException {

	public BadRequestException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
