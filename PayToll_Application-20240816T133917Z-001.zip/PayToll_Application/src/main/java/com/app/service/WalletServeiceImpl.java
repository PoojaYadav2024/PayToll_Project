package com.app.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.custom_exceptions.ResourceNotFoundException;
import com.app.dto.WalletDto;
import com.app.entities.User;
import com.app.entities.Wallet;
import com.app.repository.WalletRepository;

@Service
public class WalletServeiceImpl implements WalletService {

	@Autowired 
	private WalletRepository walletRepository;
	
	@Override
	public WalletDto retriveWalletBalance(Long user_Id) {
		User user = new User();
		user.setUserID(user_Id);
		Optional<Wallet> optionalWallet = walletRepository.findByUserID(user);
		if(optionalWallet.isEmpty()) {
			throw new ResourceNotFoundException("Wallet not found for user ID : " + user_Id );
		}
		Wallet wallet = optionalWallet.get();
		WalletDto walletDto = new WalletDto();
		walletDto.setWallet_ID(wallet.getWallet_ID());
		walletDto.setBalance_amount(wallet.getBalance_amount());
		return walletDto;
	}

	@Override
	public WalletDto updateWalletBalance(Long user_Id, double amount) {
		// TODO Auto-generated method stub
		return null;
	}

}
