package com.app.service;

import com.app.dto.VehicleDto;

public interface VehicleService {
	
	VehicleDto addVehicle(VehicleDto vehicleDto);
}
