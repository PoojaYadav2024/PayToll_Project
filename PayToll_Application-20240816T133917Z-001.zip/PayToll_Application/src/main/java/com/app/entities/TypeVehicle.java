package com.app.entities;

public enum TypeVehicle {
	CAR, TRUCK, BUS, HEAVY_VEHICLE
}
