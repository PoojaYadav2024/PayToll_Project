package com.app.entities;

public enum PayMode {
	ONLINE, CASH;
}
